package in.ac.adit.pwj.miniproject.carrental;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

// Base Car class
abstract class Car {
    String id;
    String model;
    boolean isAvailable = true;

    public Car(String id, String model) {
        this.id = id;
        this.model = model;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String toString() {
        return model + " (" + id + ")";
    }
}

class SUV extends Car {
    public SUV(String id, String model) {
        super(id, model);
    }
}

class Sedan extends Car {
    public Sedan(String id, String model) {
        super(id, model);
    }
}

// Custom Exceptions
class BookingException extends Exception {
    public BookingException(String message) {
        super(message);
    }
}

class PaymentException extends Exception {
    public PaymentException(String message) {
        super(message);
    }
}

// Main Rental System with GUI
public class CarRentalSystem {
    private final Map<String, Car> inventory = new HashMap<>();
    private final List<String> reservations = new ArrayList<>();
    private JFrame frame;
    private JTextArea outputArea;

    public CarRentalSystem() {
        initializeInventory();
        createAndShowGUI();
    }

    private void initializeInventory() {
        inventory.put("S101", new SUV("S101", "Toyota Fortuner"));
        inventory.put("S102", new SUV("S102", "Mahindra Scorpio"));
        inventory.put("D201", new Sedan("D201", "Honda City"));
        inventory.put("D202", new Sedan("D202", "Hyundai Verna"));
    }

    private void createAndShowGUI() {
        // Create main window
        frame = new JFrame("Car Rental System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        frame.setJMenuBar(menuBar);

        // Create output area
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Create buttons panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 5, 5));
        
        JButton showAvailableBtn = new JButton("Show Available Cars");
        showAvailableBtn.addActionListener(e -> showAvailableCars());
        
        JButton showAllBtn = new JButton("Show All Cars");
        showAllBtn.addActionListener(e -> showAllCars());
        
        JButton bookCarBtn = new JButton("Book a Car");
        bookCarBtn.addActionListener(e -> showBookingDialog());
        
        JButton exitBtn = new JButton("Exit");
        exitBtn.addActionListener(e -> System.exit(0));
        
        buttonPanel.add(showAvailableBtn);
        buttonPanel.add(showAllBtn);
        buttonPanel.add(bookCarBtn);
        buttonPanel.add(exitBtn);
        
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Display welcome message
        appendToOutput("Welcome to Car Rental System!\n");
        frame.setVisible(true);
    }

    private void showBookingDialog() {
        JDialog bookingDialog = new JDialog(frame, "Book a Car", true);
        bookingDialog.setLayout(new GridLayout(4, 2, 10, 10));
        bookingDialog.setSize(400, 200);

        JLabel carIdLabel = new JLabel("Car ID:");
        JTextField carIdField = new JTextField();
        
        JLabel nameLabel = new JLabel("Your Name:");
        JTextField nameField = new JTextField();
        
        JLabel amountLabel = new JLabel("Payment Amount:");
        JTextField amountField = new JTextField();
        
        JButton bookBtn = new JButton("Book Now");
        JButton cancelBtn = new JButton("Cancel");

        bookBtn.addActionListener(e -> {
            try {
                String carId = carIdField.getText();
                String name = nameField.getText();
                double amount = Double.parseDouble(amountField.getText());
                
                bookCar(carId, name, amount);
                bookingDialog.dispose();
            } catch (NumberFormatException ex) {
                appendToOutput("Error: Please enter a valid payment amount.\n");
            } catch (BookingException | PaymentException ex) {
                appendToOutput("Error: " + ex.getMessage() + "\n");
            }
        });

        cancelBtn.addActionListener(e -> bookingDialog.dispose());

        bookingDialog.add(carIdLabel);
        bookingDialog.add(carIdField);
        bookingDialog.add(nameLabel);
        bookingDialog.add(nameField);
        bookingDialog.add(amountLabel);
        bookingDialog.add(amountField);
        bookingDialog.add(bookBtn);
        bookingDialog.add(cancelBtn);

        bookingDialog.setVisible(true);
    }

    public synchronized void bookCar(String carId, String customerName, double amount) 
            throws BookingException, PaymentException {
        Car car = inventory.get(carId);

        if (car == null) {
            throw new BookingException("Car with ID " + carId + " does not exist.");
        }

        if (!car.isAvailable()) {
            throw new BookingException("Car not available: " + carId);
        }

        Payment payment = new Payment();
        if (!payment.process(customerName, amount)) {
            throw new PaymentException("Payment failed for " + customerName);
        }

        car.setAvailable(false);
        String record = "Booked: " + car + " by " + customerName + " for ₹" + amount;
        reservations.add(record);
        writeToFile(record);
        appendToOutput("Booking successful for " + customerName + " (" + car.model + ")\n");
    }

    private void writeToFile(String record) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("reservations.txt", true))) {
            writer.write(record);
            writer.newLine();
        } catch (IOException e) {
            appendToOutput("Error writing to file: " + e.getMessage() + "\n");
        }
    }

    public void showAvailableCars() {
        appendToOutput("\nAvailable Cars:\n");
        for (Car car : inventory.values()) {
            if (car.isAvailable()) {
                appendToOutput(car + "\n");
            }
        }
        appendToOutput("\n");
    }

    public void showAllCars() {
        appendToOutput("\nAll Cars in Inventory:\n");
        for (Car car : inventory.values()) {
            appendToOutput(car + " - " + (car.isAvailable() ? "Available" : "Booked") + "\n");
        }
        appendToOutput("\n");
    }

    private void appendToOutput(String text) {
        outputArea.append(text);
        outputArea.setCaretPosition(outputArea.getDocument().getLength());
    }

    class Payment {
        public boolean process(String user, double amount) {
            if (amount <= 0) {
                appendToOutput("Invalid payment amount.\n");
                return false;
            }
            
            boolean success = Math.random() > 0.1; // 90% chance of success
            if (success) {
                appendToOutput("Payment of ₹" + amount + " processed successfully for " + user + "\n");
            } else {
                appendToOutput("Payment processing failed for " + user + "\n");
            }
            return success;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CarRentalSystem());
    }
}